package com.example.dnsmonitor

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    companion object {
        val NAMES = listOf("Ping", "A", "AAAA", "CNAME")
        val COL = mapOf(
            "Ping" to 0xFF4FC3F7.toInt(),
            "A" to 0xFF81C784.toInt(),
            "AAAA" to 0xFFFFB74D.toInt(),
            "CNAME" to 0xFFBA68C8.toInt()
        )
        val BG = 0xFF14171C.toInt()
        val PANEL = 0xFF1D2128.toInt()
        val GRID = 0xFF2D333D.toInt()
        val FG = 0xFFE6E6E6.toInt()
        val MUT = 0xFF9AA4B2.toInt()
        val RED = 0xFFEF5350.toInt()
        const val VIS = 120
        const val REQ_EXPORT = 42
        val RANGE_LABELS = listOf(
            "Last 15 minutes", "Last hour", "Last 6 hours", "Last 24 hours",
            "Last 7 days", "Last 30 days", "All"
        )
        val RANGE_SECS = listOf(900L, 3600L, 21600L, 86400L, 604800L, 2592000L, 0L)
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var etServer: AutoCompleteTextView
    private lateinit var etDomain: EditText
    private lateinit var etCname: EditText
    private lateinit var etInterval: EditText
    private lateinit var tvHeader: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnLive: Button
    private lateinit var btnHist: Button
    private lateinit var liveBox: LinearLayout
    private lateinit var histBox: LinearLayout
    private lateinit var spServer: Spinner
    private lateinit var spRange: Spinner
    private lateinit var cbAuto: CheckBox

    private val liveStatus = HashMap<String, TextView>()
    private val liveStats = HashMap<String, TextView>()
    private val liveChart = HashMap<String, ChartView>()
    private val histStats = HashMap<String, TextView>()
    private val histChart = HashMap<String, ChartView>()

    private var tick = 0
    private var pendingExport: Pair<String, Long>? = null

    private val poller = object : Runnable {
        override fun run() {
            refreshLive()
            tick++
            if (histBox.visibility == View.VISIBLE && cbAuto.isChecked && tick % 5 == 0) loadHist()
            handler.postDelayed(this, 1000)
        }
    }

    // ------------------------------------------------------------------ helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun f1(x: Double): String = String.format(Locale.US, "%.1f", x)

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(MUT)
        v.textSize = 12f
        v.setPadding(0, dp(6), 0, 0)
        return v
    }

    private fun bg(): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(PANEL)
        g.cornerRadius = dp(10).toFloat()
        g.setStroke(dp(1), GRID)
        return g
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = bg()
        l.setPadding(dp(10), dp(8), dp(10), dp(10))
        return l
    }

    private fun cardLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(10)
        return lp
    }

    private fun edit(value: String, type: Int): EditText {
        val e = EditText(this)
        e.setText(value)
        e.setTextColor(FG)
        e.setSingleLine(true)
        e.inputType = type
        return e
    }

    private fun btn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weightLp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)

    private fun hideKeyboard() {
        val im = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        im.hideSoftInputFromWindow(etServer.windowToken, 0)
    }

    private fun metricCard(
        parent: LinearLayout, name: String,
        statusMap: HashMap<String, TextView>?,
        statsMap: HashMap<String, TextView>,
        chartMap: HashMap<String, ChartView>
    ) {
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val title = TextView(this)
        title.text = if (name == "Ping") "Ping" else "$name record"
        title.setTextColor(COL.getValue(name))
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, weightLp())
        if (statusMap != null) {
            val st = TextView(this)
            st.setTextColor(FG)
            st.textSize = 13f
            st.gravity = Gravity.END
            st.text = "..."
            head.addView(st, LinearLayout.LayoutParams(WRAP, WRAP))
            statusMap[name] = st
        }
        c.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val stats = TextView(this)
        stats.setTextColor(MUT)
        stats.textSize = 11f
        stats.typeface = Typeface.MONOSPACE
        c.addView(stats, LinearLayout.LayoutParams(MATCH, WRAP))
        statsMap[name] = stats
        val chart = ChartView(this)
        c.addView(chart, LinearLayout.LayoutParams(MATCH, dp(150)))
        chartMap[name] = chart
        parent.addView(c, cardLp())
    }

    // ------------------------------------------------------------------ UI
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Monitor.init(applicationContext)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Monitor.wantRunning && !Monitor.running) startMonitor()
        refreshServers()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poller)
    }

    override fun onPause() {
        handler.removeCallbacks(poller)
        super.onPause()
    }

    private fun buildUi() {
        val c = Monitor.cfg
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(24))
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))

        // ---- controls
        val ctl = card()
        ctl.addView(label("DNS server"))
        etServer = AutoCompleteTextView(this)
        etServer.setText(c.server)
        etServer.setTextColor(FG)
        etServer.setSingleLine(true)
        etServer.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        etServer.threshold = 0
        etServer.setOnClickListener { etServer.showDropDown() }
        ctl.addView(etServer, LinearLayout.LayoutParams(MATCH, WRAP))
        ctl.addView(label("A / AAAA domain"))
        etDomain = edit(c.domain, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        ctl.addView(etDomain, LinearLayout.LayoutParams(MATCH, WRAP))
        ctl.addView(label("CNAME domain (must really have a CNAME record)"))
        etCname = edit(c.cname, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        ctl.addView(etCname, LinearLayout.LayoutParams(MATCH, WRAP))
        ctl.addView(label("Interval (seconds)"))
        etInterval = edit(
            c.interval.toString(),
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        )
        ctl.addView(etInterval, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(btn("Apply") { onApply() }, weightLp())
        btnToggle = btn("Stop") { onToggle() }
        row.addView(btnToggle, weightLp())
        row.addView(btn("Clear") { Monitor.clearLive(); refreshLive() }, weightLp())
        ctl.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        ctl.addView(btn("Allow background (battery)") { onBattery() }, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(ctl, cardLp())

        tvHeader = TextView(this)
        tvHeader.setTextColor(MUT)
        tvHeader.setPadding(dp(4), 0, 0, dp(8))
        root.addView(tvHeader, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- tabs
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        btnLive = btn("Live") { showTab(true) }
        btnHist = btn("History") { showTab(false) }
        tabs.addView(btnLive, weightLp())
        tabs.addView(btnHist, weightLp())
        root.addView(tabs, cardLp())

        // ---- live
        liveBox = LinearLayout(this)
        liveBox.orientation = LinearLayout.VERTICAL
        for (n in NAMES) metricCard(liveBox, n, liveStatus, liveStats, liveChart)
        root.addView(liveBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- history
        histBox = LinearLayout(this)
        histBox.orientation = LinearLayout.VERTICAL
        histBox.visibility = View.GONE
        val hc = card()
        hc.addView(label("DNS server"))
        spServer = Spinner(this)
        spServer.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                loadHist()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        hc.addView(spServer, LinearLayout.LayoutParams(MATCH, WRAP))
        hc.addView(label("Range"))
        spRange = Spinner(this)
        val ra = ArrayAdapter(this, android.R.layout.simple_spinner_item, RANGE_LABELS)
        ra.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spRange.adapter = ra
        spRange.setSelection(1)
        spRange.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                loadHist()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        hc.addView(spRange, LinearLayout.LayoutParams(MATCH, WRAP))
        cbAuto = CheckBox(this)
        cbAuto.text = "Auto refresh (5s)"
        cbAuto.setTextColor(FG)
        hc.addView(cbAuto, LinearLayout.LayoutParams(MATCH, WRAP))
        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.addView(btn("Refresh") { loadHist() }, weightLp())
        hrow.addView(btn("Export CSV") { onExport() }, weightLp())
        hrow.addView(btn("Delete") { onDelete() }, weightLp())
        hc.addView(hrow, LinearLayout.LayoutParams(MATCH, WRAP))
        histBox.addView(hc, cardLp())
        for (n in NAMES) metricCard(histBox, n, null, histStats, histChart)
        root.addView(histBox, LinearLayout.LayoutParams(MATCH, WRAP))

        setContentView(scroll)
        showTab(true)
    }

    private fun showTab(live: Boolean) {
        liveBox.visibility = if (live) View.VISIBLE else View.GONE
        histBox.visibility = if (live) View.GONE else View.VISIBLE
        btnLive.alpha = if (live) 1f else 0.55f
        btnHist.alpha = if (live) 0.55f else 1f
        if (live) refreshLive() else refreshServers()
    }

    // ------------------------------------------------------------------ actions
    private fun startMonitor() {
        startForegroundService(Intent(this, MonitorService::class.java))
    }

    private fun onApply() {
        val iv = etInterval.text.toString().toDoubleOrNull() ?: 1.0
        try {
            Monitor.applyConfig(
                etServer.text.toString().trim(),
                etDomain.text.toString().trim(),
                etCname.text.toString().trim(),
                iv
            )
        } catch (e: Exception) {
            toast(e.message ?: "Invalid input")
            return
        }
        if (!Monitor.running) startMonitor()
        hideKeyboard()
        refreshServers()
        refreshLive()
    }

    private fun onToggle() {
        if (Monitor.running) {
            startService(Intent(this, MonitorService::class.java).setAction(MonitorService.ACTION_STOP))
        } else {
            startMonitor()
        }
        handler.postDelayed({ refreshLive() }, 400)
    }

    private fun onBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Battery restriction is already off for this app.")
        } else {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun refreshServers() {
        Thread {
            val dbList = try {
                Monitor.store.servers()
            } catch (e: Exception) {
                emptyList<String>()
            }
            val auto = LinkedHashSet<String>()
            auto.add(Monitor.cfg.server)
            auto.addAll(Monitor.savedServers())
            auto.addAll(dbList)
            auto.add("5.200.200.200")
            auto.add("8.8.8.8")
            auto.add("1.1.1.1")
            val hist = LinkedHashSet<String>()
            hist.add(Monitor.cfg.server)
            hist.addAll(dbList)
            val histList = hist.toList()
            runOnUiThread {
                etServer.setAdapter(
                    ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, auto.toList())
                )
                val cur = spServer.selectedItem as? String
                val a = ArrayAdapter(this, android.R.layout.simple_spinner_item, histList)
                a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spServer.adapter = a
                val idx = histList.indexOf(cur ?: Monitor.cfg.server)
                if (idx >= 0) spServer.setSelection(idx)
            }
        }.start()
    }

    // ------------------------------------------------------------------ live view
    private fun refreshLive() {
        val c = Monitor.cfg
        tvHeader.text = "Monitoring: ${c.server}" + (if (Monitor.running) "" else "   (stopped)")
        btnToggle.text = if (Monitor.running) "Stop" else "Start"
        if (liveBox.visibility != View.VISIBLE) return
        for (name in NAMES) {
            val snap = Monitor.snapshot(name)
            val v = if (snap.size > VIS) snap.subList(snap.size - VIS, snap.size) else snap
            val avg = FloatArray(VIS) { Float.NaN }
            val lo = FloatArray(VIS) { Float.NaN }
            val hi = FloatArray(VIS) { Float.NaN }
            val fails = IntArray(VIS)
            for ((i, s) in v.withIndex()) {
                val slot = VIS - v.size + i
                val ms = s.ms
                if (ms == null) {
                    fails[slot] = 1
                } else {
                    avg[slot] = ms.toFloat()
                    lo[slot] = ms.toFloat()
                    hi[slot] = ms.toFloat()
                }
            }
            val ok = snap.mapNotNull { it.ms }
            val last = snap.lastOrNull()
            val st = liveStatus.getValue(name)
            if (last == null) {
                st.text = "..."
                st.setTextColor(FG)
            } else if (last.ms == null) {
                st.text = "FAIL (${last.info})"
                st.setTextColor(RED)
            } else {
                st.text = "${f1(last.ms)} ms (${last.info})"
                st.setTextColor(COL.getValue(name))
            }
            val loss = if (snap.isEmpty()) 0.0 else 100.0 * (snap.size - ok.size) / snap.size
            val txt = StringBuilder()
            if (ok.isNotEmpty()) {
                txt.append("avg ${f1(ok.sum() / ok.size)}  min ${f1(ok.min())}  max ${f1(ok.max())} ms   ")
            }
            txt.append("loss ${f1(loss)}%   n=${snap.size}")
            liveStats.getValue(name).text = txt.toString()
            liveChart.getValue(name).setData(VIS, avg, lo, hi, fails, null, COL.getValue(name))
        }
    }

    // ------------------------------------------------------------------ history view
    private fun fmtT(t: Double, span: Double): String {
        val pattern = if (span <= 3600) "HH:mm:ss" else if (span <= 86400) "HH:mm" else "MM-dd HH:mm"
        return SimpleDateFormat(pattern, Locale.US).format(Date((t * 1000).toLong()))
    }

    private fun loadHist() {
        val server = spServer.selectedItem as? String ?: return
        val rng = RANGE_SECS[spRange.selectedItemPosition]
        val widthPx = histChart.getValue("Ping").width.let {
            if (it > 0) it else resources.displayMetrics.widthPixels
        }
        val nb = max(20, min(600, (widthPx - dp(46)) / dp(3)))
        Thread {
            val first = try {
                Monitor.store.firstTs(server)
            } catch (e: Exception) {
                null
            }
            if (first == null) {
                runOnUiThread {
                    for (n in NAMES) {
                        histChart.getValue(n).clearData()
                        histStats.getValue(n).text = "no data for this server yet"
                    }
                }
                return@Thread
            }
            val now = System.currentTimeMillis() / 1000.0
            val t0 = if (rng > 0) max(now - rng, first) else first
            val span = max(now - t0, 1.0)
            val labels = (0..4).map { fmtT(t0 + span * it / 4.0, span) }
            val results = NAMES.map { n ->
                Triple(
                    n,
                    Monitor.store.buckets(server, n, t0, now, nb),
                    Monitor.store.stats(server, n, t0, now)
                )
            }
            runOnUiThread {
                for ((n, buckets, st) in results) {
                    val avg = FloatArray(nb) { Float.NaN }
                    val lo = FloatArray(nb) { Float.NaN }
                    val hi = FloatArray(nb) { Float.NaN }
                    val fails = IntArray(nb)
                    for (b in buckets) {
                        val a = b.avg
                        val l = b.lo
                        val h = b.hi
                        if (a != null && l != null && h != null) {
                            avg[b.i] = a.toFloat()
                            lo[b.i] = l.toFloat()
                            hi[b.i] = h.toFloat()
                        }
                        fails[b.i] = b.fails
                    }
                    val t = StringBuilder()
                    if (st.cnt == 0) {
                        t.append("no data in this range")
                    } else {
                        t.append("samples ${st.cnt}   loss ${f1(100.0 * st.fails / st.cnt)}%")
                        val sa = st.avg
                        val smn = st.mn
                        val smx = st.mx
                        if (sa != null && smn != null && smx != null) {
                            t.append("   avg ${f1(sa)}  min ${f1(smn)}  max ${f1(smx)} ms")
                        }
                    }
                    histStats.getValue(n).text = t.toString()
                    histChart.getValue(n).setData(nb, avg, lo, hi, fails, labels, COL.getValue(n))
                }
            }
        }.start()
    }

    private fun onDelete() {
        val server = spServer.selectedItem as? String ?: return
        AlertDialog.Builder(this)
            .setTitle("Delete history")
            .setMessage("Delete ALL saved history of $server?")
            .setPositiveButton("Delete") { _, _ ->
                Thread {
                    try {
                        Monitor.store.deleteServer(server)
                    } catch (e: Exception) {
                    }
                    runOnUiThread {
                        refreshServers()
                        loadHist()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ CSV export
    private fun onExport() {
        val server = spServer.selectedItem as? String ?: return
        val rng = RANGE_SECS[spRange.selectedItemPosition]
        pendingExport = Pair(server, rng)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/csv"
        i.putExtra(Intent.EXTRA_TITLE, "dns_history_$server.csv")
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun csv(s: String): String =
        if (s.contains(',') || s.contains('"') || s.contains('\n')) "\"" + s.replace("\"", "\"\"") + "\"" else s

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_EXPORT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val pe = pendingExport ?: return
        val server = pe.first
        val rng = pe.second
        Thread {
            try {
                val first = Monitor.store.firstTs(server) ?: 0.0
                val now = System.currentTimeMillis() / 1000.0
                val t0 = if (rng > 0) max(now - rng, first) else first
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                var count = 0
                val os = contentResolver.openOutputStream(uri)
                if (os == null) {
                    runOnUiThread { toast("Cannot write file") }
                    return@Thread
                }
                BufferedWriter(OutputStreamWriter(os, Charsets.UTF_8)).use { w ->
                    w.write("\uFEFF")
                    w.write("time,server,metric,domain,ms,info\r\n")
                    Monitor.store.forEachRow(server, t0, now) { r ->
                        w.write(fmt.format(Date((r.ts * 1000).toLong())))
                        w.write(",")
                        w.write(csv(r.server))
                        w.write(",")
                        w.write(csv(r.metric))
                        w.write(",")
                        w.write(csv(r.domain))
                        w.write(",")
                        val ms = r.ms
                        w.write(if (ms == null) "" else String.format(Locale.US, "%.2f", ms))
                        w.write(",")
                        w.write(csv(r.info))
                        w.write("\r\n")
                        count++
                    }
                }
                runOnUiThread { toast("Saved $count rows") }
            } catch (e: Exception) {
                runOnUiThread { toast("Export failed: ${e.message}") }
            }
        }.start()
    }
}
