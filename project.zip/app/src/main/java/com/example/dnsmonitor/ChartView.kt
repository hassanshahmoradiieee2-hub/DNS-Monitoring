package com.example.dnsmonitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.max

/** Simple line chart: per slot avg (NaN = no data), min/max range, and failure count. */
class ChartView(context: Context) : View(context) {
    private val dens = resources.displayMetrics.density
    private var n = 0
    private var avg = FloatArray(0)
    private var lo = FloatArray(0)
    private var hi = FloatArray(0)
    private var fails = IntArray(0)
    private var labels: List<String>? = null
    private var lineColor = Color.CYAN

    private val gridP = Paint().apply {
        color = 0xFF2D333D.toInt()
        strokeWidth = dens
        style = Paint.Style.STROKE
    }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF7D8794.toInt()
        textSize = 10f * dens
    }
    private val failP = Paint().apply {
        color = 0xB8EF5350.toInt()
        style = Paint.Style.FILL
    }
    private val rangeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = dens }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dens
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun setData(
        n: Int, avg: FloatArray, lo: FloatArray, hi: FloatArray, fails: IntArray,
        labels: List<String>?, color: Int
    ) {
        this.n = n
        this.avg = avg
        this.lo = lo
        this.hi = hi
        this.fails = fails
        this.labels = labels
        this.lineColor = color
        invalidate()
    }

    fun clearData() {
        n = 0
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val left = 40f * dens
        val right = 6f * dens
        val top = 6f * dens
        val bottom = 18f * dens
        val pw = w - left - right
        val ph = h - top - bottom
        if (n <= 0 || pw < 20f || ph < 20f) return

        var mx = 10f
        for (i in 0 until n) {
            if (!hi[i].isNaN() && hi[i] > mx) mx = hi[i]
        }
        val ym = mx * 1.15f

        textP.textAlign = Paint.Align.RIGHT
        for (i in 0..4) {
            val y = top + ph * i / 4f
            c.drawLine(left, y, w - right, y, gridP)
            c.drawText(Math.round(ym * (1f - i / 4f)).toString(), left - 4f * dens, y + 3f * dens, textP)
        }
        val ls = labels
        if (ls != null && ls.size > 1) {
            for (i in ls.indices) {
                textP.textAlign = when (i) {
                    0 -> Paint.Align.LEFT
                    ls.size - 1 -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
                c.drawText(ls[i], left + pw * i / (ls.size - 1), h - 4f * dens, textP)
            }
        }

        val bw = max(2f * dens, pw / n)
        fun xf(i: Int): Float = left + pw * (i + 0.5f) / n
        fun yf(v: Float): Float = top + ph * (1f - v / ym)

        for (i in 0 until n) {
            if (fails[i] > 0) c.drawRect(xf(i) - bw / 2, top, xf(i) + bw / 2, top + ph, failP)
        }
        rangeP.color = Color.argb(0x66, Color.red(lineColor), Color.green(lineColor), Color.blue(lineColor))
        for (i in 0 until n) {
            if (!avg[i].isNaN() && !hi[i].isNaN() && !lo[i].isNaN() && hi[i] > lo[i]) {
                c.drawLine(xf(i), yf(lo[i]), xf(i), yf(hi[i]), rangeP)
            }
        }
        lineP.color = lineColor
        dotP.color = lineColor
        val path = Path()
        var on = false
        for (i in 0 until n) {
            if (avg[i].isNaN()) {
                if (on) {
                    c.drawPath(path, lineP)
                    path.reset()
                    on = false
                }
                continue
            }
            if (!on) {
                path.moveTo(xf(i), yf(avg[i]))
                on = true
            } else {
                path.lineTo(xf(i), yf(avg[i]))
            }
            c.drawCircle(xf(i), yf(avg[i]), 1.6f * dens, dotP)
        }
        if (on) c.drawPath(path, lineP)
    }
}
