package com.example.dnsmonitor

import java.io.ByteArrayOutputStream
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.IDN
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** Result of one measurement: ms == null means failure, info explains. */
data class Res(val ms: Double?, val info: String)

object Net {
    private val timeRe = Regex("""[=<]\s*(\d+(?:\.\d+)?)\s*ms""", RegexOption.IGNORE_CASE)
    private val types = mapOf("A" to 1, "CNAME" to 5, "AAAA" to 28)

    /** Fallback when the ping binary is unavailable: TCP connect time to port 53. */
    fun tcpPing(host: String, timeoutMs: Int = 2000): Res {
        val t0 = System.nanoTime()
        return try {
            Socket().use { s -> s.connect(InetSocketAddress(host, 53), timeoutMs) }
            Res((System.nanoTime() - t0) / 1e6, "tcp53")
        } catch (e: ConnectException) {
            if ((e.message ?: "").contains("refused", ignoreCase = true)) {
                Res((System.nanoTime() - t0) / 1e6, "tcp53 (refused)")
            } else {
                Res(null, "timeout")
            }
        } catch (e: Exception) {
            Res(null, "timeout")
        }
    }

    fun pingOnce(host: String): Res {
        return try {
            val p = ProcessBuilder("ping", "-c", "1", "-W", "2", host)
                .redirectErrorStream(true)
                .start()
            val out = p.inputStream.bufferedReader().readText()
            if (!p.waitFor(6, TimeUnit.SECONDS)) {
                p.destroy()
                return Res(null, "timeout")
            }
            val code = p.exitValue()
            val m = timeRe.find(out)
            if (code == 0 && m != null) {
                if (m.value.contains("<")) Res(1.0, "<1ms") else Res(m.groupValues[1].toDouble(), "OK")
            } else if (code == 126 || code == 127 || out.isBlank()) {
                tcpPing(host)
            } else {
                Res(null, "timeout")
            }
        } catch (e: Exception) {
            tcpPing(host)
        }
    }

    private fun u16(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    private fun skipName(b: ByteArray, start: Int): Int {
        var off = start
        while (true) {
            val l = b[off].toInt() and 0xFF
            if (l == 0) return off + 1
            if ((l and 0xC0) == 0xC0) return off + 2
            off += l + 1
        }
    }

    fun dnsQuery(server: String, name: String, qtypeName: String, timeoutMs: Int = 2000): Res {
        val qtype = types[qtypeName] ?: return Res(null, "bad type")
        var sock: DatagramSocket? = null
        try {
            val qid = Random.nextInt(0, 65536)
            val out = ByteArrayOutputStream()
            fun w16(v: Int) {
                out.write((v shr 8) and 0xFF)
                out.write(v and 0xFF)
            }
            w16(qid); w16(0x0100); w16(1); w16(0); w16(0); w16(0)
            for (label in IDN.toASCII(name.trim('.')).split('.')) {
                val lb = label.toByteArray(Charsets.US_ASCII)
                out.write(lb.size)
                out.write(lb)
            }
            out.write(0)
            w16(qtype); w16(1)
            val pkt = out.toByteArray()

            val addr = InetAddress.getByName(server)
            sock = DatagramSocket()
            sock.soTimeout = timeoutMs
            val t0 = System.nanoTime()
            sock.send(DatagramPacket(pkt, pkt.size, addr, 53))
            val buf = ByteArray(4096)
            val resp = DatagramPacket(buf, buf.size)
            while (true) {
                sock.receive(resp)
                if (resp.length >= 12 && u16(buf, 0) == qid) break
            }
            val ms = (System.nanoTime() - t0) / 1e6

            val rcode = u16(buf, 2) and 0xF
            if (rcode != 0) {
                val txt = when (rcode) {
                    3 -> "NXDOMAIN"
                    2 -> "SERVFAIL"
                    5 -> "REFUSED"
                    else -> "RCODE $rcode"
                }
                return Res(null, txt)
            }
            val qd = u16(buf, 4)
            val an = u16(buf, 6)
            var off = 12
            for (i in 0 until qd) off = skipName(buf, off) + 4
            var found = 0
            for (i in 0 until an) {
                off = skipName(buf, off)
                val rtype = u16(buf, off)
                val rdlen = u16(buf, off + 8)
                off += 10 + rdlen
                if (rtype == qtype) found++
            }
            if (found == 0) return Res(null, "no $qtypeName record")
            return Res(ms, "$found rec")
        } catch (e: SocketTimeoutException) {
            return Res(null, "timeout")
        } catch (e: Exception) {
            return Res(null, (e.message ?: e.javaClass.simpleName).take(30))
        } finally {
            sock?.close()
        }
    }
}
