package com.example.dnsmonitor

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future

data class Config(val server: String, val domain: String, val cname: String, val interval: Double)

data class Sample(val ts: Double, val ms: Double?, val info: String)

/** Process-wide monitor. The foreground service starts/stops it; the UI only reads from it. */
object Monitor {
    const val LIVE_KEEP = 300
    val METRICS = listOf("Ping", "A", "AAAA", "CNAME")
    private val NAME_RE = Regex("^[A-Za-z0-9][A-Za-z0-9.\\-:]*$")

    @Volatile
    var cfg = Config("5.200.200.200", "google.com", "www.github.com", 1.0)

    @Volatile
    var running = false

    @Volatile
    private var gen = 0

    @Volatile
    private var token = 0

    lateinit var store: Store
    private lateinit var prefs: SharedPreferences
    private var inited = false

    private val live: Map<String, ArrayList<Sample>> = METRICS.associateWith { ArrayList<Sample>() }
    private val pool: ExecutorService = Executors.newFixedThreadPool(4) { r ->
        val t = Thread(r)
        t.isDaemon = true
        t
    }

    @Synchronized
    fun init(ctx: Context) {
        if (inited) return
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        store = Store(app)
        val d = cfg
        cfg = Config(
            prefs.getString("server", d.server) ?: d.server,
            prefs.getString("domain", d.domain) ?: d.domain,
            prefs.getString("cname", d.cname) ?: d.cname,
            prefs.getString("interval", "1")?.toDoubleOrNull() ?: 1.0
        )
        try {
            store.deleteOld()
        } catch (e: Exception) {
        }
        inited = true
    }

    val wantRunning: Boolean
        get() = prefs.getBoolean("running", true)

    fun savedServers(): List<String> =
        (prefs.getString("servers", "") ?: "").split(",").filter { it.isNotBlank() }

    fun applyConfig(server: String, domain: String, cname: String, interval: Double) {
        for (v in listOf(server, domain, cname)) {
            if (!NAME_RE.matches(v)) throw IllegalArgumentException("Invalid name: $v")
        }
        val iv = if (interval < 0.5) 0.5 else interval
        cfg = Config(server, domain, cname, iv)
        val saved = LinkedHashSet<String>()
        saved.add(server)
        saved.addAll(savedServers())
        prefs.edit()
            .putString("server", server)
            .putString("domain", domain)
            .putString("cname", cname)
            .putString("interval", iv.toString())
            .putString("servers", saved.take(20).joinToString(","))
            .apply()
        gen++
        clearLive()
    }

    fun clearLive() {
        for (l in live.values) synchronized(l) { l.clear() }
    }

    fun snapshot(metric: String): List<Sample> {
        val l = live[metric] ?: return emptyList()
        return synchronized(l) { ArrayList(l) }
    }

    fun summary(): String {
        val sb = StringBuilder()
        for (m in METRICS) {
            val s = snapshot(m).lastOrNull()
            if (sb.isNotEmpty()) sb.append("  |  ")
            sb.append(m).append(' ')
            if (s == null) {
                sb.append('-')
            } else {
                val v = s.ms
                if (v == null) sb.append("x") else sb.append(String.format(Locale.US, "%.0f", v))
            }
        }
        return sb.toString()
    }

    @Synchronized
    fun start() {
        if (running) return
        running = true
        token++
        prefs.edit().putBoolean("running", true).apply()
        val my = token
        Thread { loop(my) }.start()
    }

    @Synchronized
    fun stop(persist: Boolean = true) {
        running = false
        token++
        if (persist) prefs.edit().putBoolean("running", false).apply()
    }

    private fun loop(myToken: Int) {
        while (running && token == myToken) {
            val t0 = System.currentTimeMillis()
            val g = gen
            val c = cfg
            val jobs = LinkedHashMap<String, Future<Res>>()
            val doms = HashMap<String, String>()
            jobs["Ping"] = pool.submit(Callable { Net.pingOnce(c.server) })
            doms["Ping"] = ""
            jobs["A"] = pool.submit(Callable { Net.dnsQuery(c.server, c.domain, "A") })
            doms["A"] = c.domain
            jobs["AAAA"] = pool.submit(Callable { Net.dnsQuery(c.server, c.domain, "AAAA") })
            doms["AAAA"] = c.domain
            jobs["CNAME"] = pool.submit(Callable { Net.dnsQuery(c.server, c.cname, "CNAME") })
            doms["CNAME"] = c.cname

            val rows = ArrayList<Row>()
            for ((name, f) in jobs) {
                val r = try {
                    f.get()
                } catch (e: Exception) {
                    Res(null, "error")
                }
                if (g == gen && token == myToken) {
                    val ts = System.currentTimeMillis() / 1000.0
                    val l = live[name]
                    if (l != null) {
                        synchronized(l) {
                            l.add(Sample(ts, r.ms, r.info))
                            while (l.size > LIVE_KEEP) l.removeAt(0)
                        }
                    }
                    rows.add(Row(ts, c.server, name, doms[name] ?: "", r.ms, r.info))
                }
            }
            if (rows.isNotEmpty()) {
                try {
                    store.addBatch(rows)
                } catch (e: Exception) {
                }
            }
            val wait = (c.interval * 1000).toLong() - (System.currentTimeMillis() - t0)
            if (wait > 0) {
                try {
                    Thread.sleep(wait)
                } catch (e: InterruptedException) {
                }
            }
        }
    }
}
