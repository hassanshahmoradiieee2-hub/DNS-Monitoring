package com.example.dnsmonitor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale

data class Row(
    val ts: Double,
    val server: String,
    val metric: String,
    val domain: String,
    val ms: Double?,
    val info: String
)

data class Bucket(
    val i: Int,
    val avg: Double?,
    val lo: Double?,
    val hi: Double?,
    val fails: Int,
    val cnt: Int
)

data class Stats(val cnt: Int, val fails: Int, val avg: Double?, val mn: Double?, val mx: Double?)

/** Same table layout as the Windows/Python version (dns_monitor_history.db). */
class Store(context: Context) : SQLiteOpenHelper(context, "dns_monitor_history.db", null, 1) {

    companion object {
        const val RETENTION_DAYS = 30
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS samples(" +
                "ts REAL, server TEXT, metric TEXT, domain TEXT, ms REAL, info TEXT)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS ix ON samples(server, metric, ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun d(x: Double): String = String.format(Locale.US, "%.6f", x)

    @Synchronized
    fun deleteOld() {
        val cutoff = System.currentTimeMillis() / 1000.0 - RETENTION_DAYS * 86400.0
        writableDatabase.execSQL("DELETE FROM samples WHERE ts < ${d(cutoff)}")
    }

    @Synchronized
    fun addBatch(rows: List<Row>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (r in rows) {
                val cv = ContentValues()
                cv.put("ts", r.ts)
                cv.put("server", r.server)
                cv.put("metric", r.metric)
                cv.put("domain", r.domain)
                if (r.ms == null) cv.putNull("ms") else cv.put("ms", r.ms)
                cv.put("info", r.info)
                db.insert("samples", null, cv)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun servers(): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery(
            "SELECT server FROM samples GROUP BY server ORDER BY MAX(ts) DESC", null
        ).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    fun firstTs(server: String): Double? {
        readableDatabase.rawQuery(
            "SELECT MIN(ts) FROM samples WHERE server=?", arrayOf(server)
        ).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) return c.getDouble(0)
        }
        return null
    }

    fun buckets(server: String, metric: String, t0: Double, t1: Double, nb: Int): List<Bucket> {
        val bs = maxOf((t1 - t0) / nb, 1e-6)
        val map = LinkedHashMap<Int, Bucket>()
        val sql = "SELECT CAST((ts-${d(t0)})/${d(bs)} AS INTEGER), AVG(ms), MIN(ms), MAX(ms), " +
            "SUM(ms IS NULL), COUNT(*) FROM samples " +
            "WHERE server=? AND metric=? AND ts>=${d(t0)} AND ts<=${d(t1)} GROUP BY 1"
        readableDatabase.rawQuery(sql, arrayOf(server, metric)).use { c ->
            while (c.moveToNext()) {
                val idx = minOf(maxOf(c.getInt(0), 0), nb - 1)
                val b = Bucket(
                    idx,
                    if (c.isNull(1)) null else c.getDouble(1),
                    if (c.isNull(2)) null else c.getDouble(2),
                    if (c.isNull(3)) null else c.getDouble(3),
                    c.getInt(4),
                    c.getInt(5)
                )
                val old = map[idx]
                if (old == null) {
                    map[idx] = b
                } else {
                    map[idx] = Bucket(
                        idx, b.avg ?: old.avg, b.lo ?: old.lo, b.hi ?: old.hi,
                        old.fails + b.fails, old.cnt + b.cnt
                    )
                }
            }
        }
        return map.values.toList()
    }

    fun stats(server: String, metric: String, t0: Double, t1: Double): Stats {
        val sql = "SELECT COUNT(*), SUM(ms IS NULL), AVG(ms), MIN(ms), MAX(ms) FROM samples " +
            "WHERE server=? AND metric=? AND ts>=${d(t0)} AND ts<=${d(t1)}"
        readableDatabase.rawQuery(sql, arrayOf(server, metric)).use { c ->
            if (c.moveToFirst()) {
                return Stats(
                    c.getInt(0),
                    c.getInt(1),
                    if (c.isNull(2)) null else c.getDouble(2),
                    if (c.isNull(3)) null else c.getDouble(3),
                    if (c.isNull(4)) null else c.getDouble(4)
                )
            }
        }
        return Stats(0, 0, null, null, null)
    }

    fun forEachRow(server: String, t0: Double, t1: Double, fn: (Row) -> Unit) {
        val sql = "SELECT ts, server, metric, domain, ms, info FROM samples " +
            "WHERE server=? AND ts>=${d(t0)} AND ts<=${d(t1)} ORDER BY ts, metric"
        readableDatabase.rawQuery(sql, arrayOf(server)).use { c ->
            while (c.moveToNext()) {
                fn(
                    Row(
                        c.getDouble(0),
                        c.getString(1) ?: "",
                        c.getString(2) ?: "",
                        c.getString(3) ?: "",
                        if (c.isNull(4)) null else c.getDouble(4),
                        c.getString(5) ?: ""
                    )
                )
            }
        }
    }

    @Synchronized
    fun deleteServer(server: String) {
        writableDatabase.delete("samples", "server=?", arrayOf(server))
    }
}
