# DNS Monitor (اپ اندروید)

پایش پینگ و سرعت پاسخ DNS (رکوردهای A / AAAA / CNAME) با نمودار زنده، ذخیره‌ی سوابق، خروجی CSV و تغییر آزادانه‌ی سرور DNS.
با Foreground Service کار می‌کند، یعنی با اعلان دائمی در پس‌زمینه زنده می‌ماند.

ساخت APK: فایل `.github/workflows/build.yml` را در GitHub بگذارید و تب Actions را ببینید.
